cd ../data/

velocyto run10x -m ../ref/mm10_rmsk.gtf old1 ../ref/gencode.vM12.annotation.gtf
velocyto run10x -m ../ref/mm10_rmsk.gtf old2 ../ref/gencode.vM12.annotation.gtf
velocyto run10x -m ../ref/mm10_rmsk.gtf old3 ../ref/gencode.vM12.annotation.gtf
velocyto run10x -m ../ref/mm10_rmsk.gtf young1 ../ref/gencode.vM12.annotation.gtf
velocyto run10x -m ../ref/mm10_rmsk.gtf young2 ../ref/gencode.vM12.annotation.gtf
velocyto run10x -m ../ref/mm10_rmsk.gtf young3 ../ref/gencode.vM12.annotation.gtf
